package base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class WrapperClass 
{
	public static WebDriver driver;
	public static void launchApplication(String browser,String url)
	{
		try
		{
			//to launch Chrome browser
			if(browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver","./src/test/resources/drivers/chromedriver.exe");
				driver = new ChromeDriver();
			}
			//to launch Microsoft Edge browser
			else if(browser.equalsIgnoreCase("edge"))
			{
				System.setProperty("webdriver.edge.driver","./src/test/resources/drivers/msedgedriver.exe");
				driver = new EdgeDriver();
			}
			driver.manage().window().maximize();//to maximize the browser window
			driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.navigate().to(url);//to open application
		}
		catch(WebDriverException e)
		{
			System.out.println("browser could not be launched");
		}
	}
	public static void closeBrowser()
	{
		driver.close();
	}
}