package excelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.*;

public class ExcelData 
{
	String data;
	public String readExcel(String filepath,String sheetNumber, int rowNumber, int cellNumber) throws IOException, FileNotFoundException
	{
		File file = new File(filepath);
		FileInputStream inputfile = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(inputfile);
		XSSFSheet sheet = workbook.getSheet(sheetNumber);
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.getCell(cellNumber);
		data = cell.getStringCellValue();
		return data;
	}
}